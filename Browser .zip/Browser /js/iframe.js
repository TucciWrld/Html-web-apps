(function () {
  var iframe = document.getElementById('iframe');
  var menuBack = document.getElementById('menu-back'),
    menuForward = document.getElementById('menu-forward'),
    menuRefresh = document.getElementById('menu-refresh'),
    menuHome = document.getElementById('menu-home'),
    menuFullScreen = document.getElementById('menu-full-screen');

  var maximize = document.getElementsByClassName('aid-icon-browser-maximize')[0];
  var minimize = document.getElementsByClassName('aid-icon-minimize')[0];

  var address = document.getElementById('address');
  var fullScreenState = false;
  setFullScreenIcon(false);

  menuBack.addEventListener('click', function () {
    window.history.back();
    address.value = iframe.src;
  });

  menuForward.addEventListener('click', function () {
    window.history.forward();
    address.value = iframe.src;
  });

  menuRefresh.addEventListener('click', function () {
    window.location.reload();
  });

  menuHome.addEventListener('click', function () {
    iframe.src = './navigation.html';
  });

  menuFullScreen.addEventListener('click', function () {
    var docElm = document.documentElement;
    if (!fullScreenState) {
      if (docElm.requestFullscreen) {
        docElm.requestFullscreen();
      } else if (docElm.mozRequestFullScreen) {
        docElm.mozRequestFullScreen();
      } else if (docElm.webkitRequestFullScreen) {
        docElm.webkitRequestFullScreen();
      } else if (docElm.msRequestFullscreen) {
        docElm.msRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitCancelFullScreen) {
        document.webkitCancelFullScreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
    }
  });

  function setFullScreenIcon(flag) {
    if (flag) {
      minimize.style.display = 'block';
      maximize.style.display = 'none';
    } else {
      maximize.style.display = 'block';
      minimize.style.display = 'none';
    }
  }

  document.addEventListener('fullscreenchange', function () {
    if (document.fullscreenElement !== null) {
      fullScreenState = true;
      setFullScreenIcon(true);
      var localTheme = localStorage.getItem('aid_theme') || ThemeValue.light;
      if (localTheme == ThemeValue.light) {
        document.getElementById('iframe').style.background =
          'rgba(234, 234, 234, 0.82)';
      } else {
        document.getElementById('iframe').style.background =
          'rgba(48, 48, 48, 0.82)';
      }
    } else {
      fullScreenState = false;
      setFullScreenIcon(false);
      document.getElementById('iframe').style.background = 'transparent';
    }
  });
})();
